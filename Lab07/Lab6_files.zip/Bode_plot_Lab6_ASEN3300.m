%% Question 2

clear all; clc; close all;

Vpp_in = 2.00; %[V]
Vpp_out = [6.40; 6.40; 6.40; 6.40; 6.12; 2.64; 1.32; .640; .280]; %[v]
Freq = [1; 2; 5; 10; 20; 50; 100; 200; 500]*1000; % [Hz]

V_amp = Vpp_out/Vpp_in;
dBVpp = 20*log10(Vpp_out/Vpp_in);

figure()
semilogx(Freq,dBVpp)
xlabel('Frequency[Hz]'); ylabel('dBV'); title('Bode Plot')
line = dBVpp(1) - 3;
yline(line,'--')

%% Question 4

L7_data = readtable('lab06_section04_signal7in.csv');
L9_data = readtable('lab06_section04_signal9in.csv');
L11_data = readtable('lab06_section04_signal11in.csv');

figure()
plot(L7_data.Time_s_(:,1),L7_data.Channel1_V_(:,1))
title('Length 7 inches'); xlabel('Time [s]'); ylabel('Voltage [V]');
F_s7 = 1/(L7_data.Time_s_(2,1) - L7_data.Time_s_(1,1)); 

figure()
plot(L9_data.Time_s_(:,1),L9_data.Channel1_V_(:,1))
title('Length 9 inches'); xlabel('Time [s]'); ylabel('Voltage [V]');
F_s9 = 1/(L9_data.Time_s_(2,1) - L9_data.Time_s_(1,1));

figure()
plot(L11_data.Time_s_(:,1),L11_data.Channel1_V_(:,1))
title('Length 11 inches'); xlabel('Time [s]'); ylabel('Voltage [V]');
F_s11 = 1/(L11_data.Time_s_(2,1) - L11_data.Time_s_(1,1));